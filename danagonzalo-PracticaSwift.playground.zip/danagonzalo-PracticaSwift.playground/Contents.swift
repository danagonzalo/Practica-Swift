import Foundation


// Diferentes clientes que hemos creado dados su nombre, edad y altura en centímetros
let cliente1 = Client(name: "Soila Vaca", age: 25, height: 159)
let cliente2 = Client(name: "Debora Melo", age: 28, height: 183)
let cliente3 = Client(name: "Elsa Capuntas", age: 51, height: 158)
let cliente4 = Client(name: "Elson Brero", age: 23, height: 160)
let cliente5 = Client(name: "Elena Nito", age: 55, height: 164)
let cliente6 = Client(name: "Ali Cate", age: 32, height: 177)
let cliente7 = Client(name: "La Sor Rainmunda", age: 73, height: 157)
let cliente8 = Client(name: "Lucila Tanga", age: 19, height: 182)
let cliente9 = Client(name: "Solomeo Paredes", age: 46, height: 190)
let cliente10 = Client(name: "Elvis Teck", age: 61, height: 172)

let listaClientes1 = [cliente1, cliente2, cliente1, cliente1, cliente1, cliente2]
let listaClientes2 = [cliente3, cliente4, cliente6, cliente6, cliente5, cliente4]
let listaClientes3 = [cliente10, cliente1]
let listaClientes4 = [cliente7, cliente7, cliente8, cliente8, cliente8, cliente9]



// Creamos una instancia de HotelReservationManager
var hotelReservationManager = HotelReservationanager()



// Añadimos diferentes reservas dada la lista de clientes, la duración de la estancia en días y la opción de desayuno
// Cada caso tiene un do-catch para que el programa no se pare en caso de error

do {
    print("Eliminando reserva cuando lista está vacía...")

    let reservationToCancel = hotelReservationManager.reservationsList.first
    try hotelReservationManager.cancelReservation(reservationToCancel?.key)

} catch let error {
    print(error.localizedDescription)
}



do {
    print("Añadiendo primera reserva...")
    
    // Añadimos reservas con clientes repetidos en la misma reserva
    try hotelReservationManager.addReservation(clientsList: listaClientes1, lenghtOfStay: 3, breakfastIncluded: true)

} catch let error {
    print(error.localizedDescription)
}


do {
    print("Añadiendo segunda reserva...")
    
    try hotelReservationManager.addReservation(clientsList: listaClientes2, lenghtOfStay: 5, breakfastIncluded: false)
    
} catch let error {
    print(error.localizedDescription)
}
  


do {
    print("Añadiendo tercera reserva con cliente repetido...")
    
    // ERROR: No se puede añadir una reserva con un cliente que ya está en otra reserva
    try hotelReservationManager.addReservation(clientsList: listaClientes3, lenghtOfStay: 1, breakfastIncluded: false)

} catch let error {
    print(error.localizedDescription)
}



do {
    print("Añadiendo cuarta reserva...")
    
    try hotelReservationManager.addReservation(clientsList: listaClientes4, lenghtOfStay: 4, breakfastIncluded: true)

} catch let error {
    print(error.localizedDescription)
}



// ERROR: No hay reserva con ese ID
do {
    print("Eliminando reserva con ID que no está en la lista...")
    try hotelReservationManager.cancelReservation(UUID())

} catch let error {
    print(error.localizedDescription)
}



do {
    print("Eliminando primera reserva de la lista...")
    
    let reservationToCancel = hotelReservationManager.reservationsList.first
    try hotelReservationManager.cancelReservation(reservationToCancel?.key)

} catch let error {
    print(error.localizedDescription)
}



//Mostramos por consola toda la información de las reservas que hemos añadido
hotelReservationManager.showReservations()

