import Foundation

/// Clase `HotelReservationManager`, gestiona las reservas del Hotel Luchadores
public class HotelReservationanager {
    
    let hotelName = "HOTEL LUCHADORES"
    public var reservationsList = [UUID : Reservation]()
    let basePrice: Double = 20
    let breakfastPrice = 1.25
    
    public init(){}
    
    
    // ----------------------------------------

    
    /// Añade una reserva nueva a la lista de reservas
    ///  - `clientsList`: array de clientes que harán la reserva
    ///  - `lenghtOfStay`: duración de la estancia en días
    ///  - `breakfastIncluded`: `true` si el cliente quiere desayuno
    public func addReservation(clientsList: [Client], lenghtOfStay: UInt, breakfastIncluded: Bool) throws {
        
        let reservationId = UUID() // identificador único de la reserva
        let newClientsList = Set(clientsList) //eliminamos los clientes repetidos
        var clientFound = false

        
        // iteramos la lista de reservas del hotel para ver si algún cliente ya tiene una reserva
        self.reservationsList.values.forEach { reservation in
            //para cada reserva iteramos su lista de huéspedes (clientes)
            reservation.clientsList.forEach { client in
                // si algún cliente de la lista de clientes que queremos añadir ya existe en la reserva, clientFound = true
                if newClientsList.description.contains(client.name) {
                    clientFound = true
                }
            }
        }

        
        // Verificamos que el ID sea único y que el cliente no esté en otra reserva
        if self.reservationsList.keys.contains(reservationId) {
            throw ReservationError.idAlreadyFound
            
        } else if clientFound {
            throw ReservationError.clientAlreadyFound
            
        // Si nada falla, la reserva se puede realizar
        } else {
            // calcula el precio total de la reserva
            let reservationPrice = calculateTotalPrice(numberOfClients: UInt( newClientsList.count), lenghtOfStay, breakfastIncluded)

            // crea la reserva nueva y la añade a la lista del hotel
            let newReservation = Reservation(self.hotelName, reservationId, newClientsList, lenghtOfStay, breakfastIncluded, reservationPrice)
            
            self.reservationsList.updateValue(newReservation, forKey: reservationId)
        }
    }
    
    
    // ----------------------------------------

    
    /// Calcula el precio total de una reserva y lo devuelve
    /// - `numberOfClients`: cantidad de clientes que hacen la reserva
    /// - `lenghtOfStay`: duración de la estancia en días
    /// - `breakfastIncluded`: opción de desayuno
    public func calculateTotalPrice(numberOfClients: UInt, _ lenghtOfStay: UInt, _ breakfastIncluded: Bool) -> Double {
        
        // calculamos el precio de la reserva sin desayuno
        var totalPrice = Double(numberOfClients) * self.basePrice * Double(lenghtOfStay)

        // añadimos el precio del desayuno si el cliente lo ha elegido
        if breakfastIncluded {
            totalPrice *= self.breakfastPrice
        }
        
        return totalPrice
    }

    
    // ----------------------------------------

    
    /// Comprueba si la lista de reservas está vacía y, si  no lo está, comprueba si una reserva existe y la elimina de la lista
    /// - `reservationId`: identificador de la reserva que se quiere eliminar
    public func cancelReservation(_ reservationId: UUID?) throws {
        
        // Comprobamos que la lista de reservas no está vacía
        if self.reservationsList.count == 0 {
            throw   ReservationError.notFound
        }
        
        // Verificamos que exista una reserva con el ID pasado por parámetros
        if !self.reservationsList.keys.contains(reservationId!) {
            throw ReservationError.notFound
        }
        
        // Si todo está bien, cancelamos la reserva
        else {
            self.reservationsList.removeValue(forKey: reservationId!)
        }
    }
    
    
    // ----------------------------------------
    
    
    /// Muestra por consola la lista de reservas del hotel
    public func showReservations() {
        print("\n========== \(self.hotelName) ==========\n")
        print (self.reservationsList.values)
    }
}
