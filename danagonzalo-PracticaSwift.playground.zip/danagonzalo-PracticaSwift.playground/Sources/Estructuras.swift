import Foundation


// ---------- Structs ----------

/// Estructura `Client`. Representa a una persona, que será cliente en un hotel.
/// - `name`: el nombre del cliente que va a realizar la reserva,
/// - `age`: edad del cliente,
/// - `height`: altura del cliente en centímetros
public struct Client: Hashable, CustomStringConvertible {
    var name: String
    private let age: UInt8
    private let height: UInt
    
    public init(name: String, age: UInt8, height: UInt) {
        self.name = name
        self.age = age
        self.height = height
    }
    
    public var description: String {
        return "        👤 \(self.name), \(self.age) year(s) old and \(self.height)cm tall\n"
    }
}

/// Estructura `Reservation`. Representa una reserva hecha en un hotel.
/// - `id`: identificador único de la reserva
/// - `hotelName`: nombre del hotel donde se realiza la reserva
/// - `clientsList`: lista de huéspedes de la reserva, sin repetidos
/// - `lenghtOfStay`: duración de la estancia en días
/// - `price`: precio total de la reserva
/// - `breakfastIncluded`: opción de incluir desayuno
public struct Reservation: CustomStringConvertible {
    
    public let id: UUID
    let hotelName: String
    var clientsList: Set<Client>
    let lenghtOfStay: UInt
    let breakfastIncluded: Bool
    let price: Double
    
    public init(_ hotelName: String, _ id: UUID, _ clientsList: Set<Client>, _ lenghtOfStay: UInt, _ breakfastIncluded: Bool, _ price: Double) {
        
        self.hotelName = hotelName
        self.id = id
        self.clientsList = Set(clientsList)
        self.lenghtOfStay = lenghtOfStay
        self.breakfastIncluded = breakfastIncluded
        self.price = price
    }
    
    
    public var description: String {
        var description: String
        
        description = "📝 Reservation ID: \(self.id)\n"
        description += "      🏨 Lenght of stay: \(self.lenghtOfStay) days\n"
        // Solo muestra la opción desayuno si el cliente lo ha elegido.
        description += self.breakfastIncluded ? "      ☕️ Breakfast included\n" : ""
        description += "      👥 Guests:\n \(self.clientsList)\n"
        description += "--------------------------------------\n"
        description += "          💰 TOTAL: \(String(format: "%.2f", self.price))€\n"
        description += "=======================================\n\n\n"
        return description
    }
}
    
    
// ---------- Enums ----------
    
/// Enumerado con los tres posibles errores que puede lanzar el programa:
/// se encontró reserva con el mismo ID, se encontró reserva para un cliente y no se encontró la reserva.
public enum ReservationError: LocalizedError {
    case idAlreadyFound
    case clientAlreadyFound
    case notFound
    
    public var errorDescription: String? {
        switch self {
        case .idAlreadyFound:
            return "⚠️⚠️⚠️ Ya existe una reserva con el id ⚠️⚠️⚠️"
        case .clientAlreadyFound:
            return "⚠️⚠️⚠️ Ya existe una reserva para ese cliente ⚠️⚠️⚠️"
        case .notFound:
            return "⚠️⚠️⚠️ No se ha encontrado una reserva con ese ID ⚠️⚠️⚠️"
        }
    }
}

